Convert the below HTML/CSS code into React component. Do not include the global components as these already exist:

<nav id="header-main" class="fixed top-0 w-full z-50 backdrop-blur-xl bg-black/40 border-b border-white/10 transition-all duration-300">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-20">
            <!-- Logo -->
            <div class="flex-shrink-0 flex items-center gap-2 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.5)] group-hover:shadow-[0_0_30px_rgba(6,182,212,0.8)] transition-all duration-500">
                    <i class="fa-solid fa-shield-halved text-white text-lg"></i>
                </div>
                <span class="text-2xl font-bold bg-gradient-to-r from-white via-blue-100 to-gray-400 bg-clip-text text-transparent tracking-tight">ZAFESYS</span>
            </div>

            <!-- Desktop Nav -->
            <div class="hidden md:flex items-center gap-8">
                <a href="#section-hero" class="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group">
                    Inicio
                    <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-cyan-400 transition-all duration-300 group-hover:w-full"></span>
                </a>
                <a href="#section-products" class="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group">
                    Catálogo
                    <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-cyan-400 transition-all duration-300 group-hover:w-full"></span>
                </a>
                <a href="#section-features" class="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group">
                    Tecnología
                    <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-cyan-400 transition-all duration-300 group-hover:w-full"></span>
                </a>
                <a href="#section-support" class="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group">
                    Soporte
                    <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-cyan-400 transition-all duration-300 group-hover:w-full"></span>
                </a>
            </div>

            <!-- CTA Button -->
            <div class="hidden md:flex items-center gap-4">
                <button class="relative px-6 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm font-semibold text-white overflow-hidden group hover:border-cyan-500/50 transition-all duration-300">
                    <span class="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                    <span class="relative flex items-center gap-2">
                        <i class="fa-brands fa-whatsapp text-green-400"></i>
                        Asesoría
                    </span>
                </button>
            </div>

            <!-- Mobile menu button -->
            <div class="md:hidden flex items-center">
                <button class="text-gray-300 hover:text-white p-2">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
            </div>
        </div>
    </div>
</nav>

<main id="main-content" class="relative bg-black">
    
    <!-- Hero Section -->
    <section id="section-hero" class="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-20">
        <!-- Background with Overlay -->
        <div class="absolute inset-0 z-0">
            <img src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Modern Home" class="w-full h-full object-cover opacity-40 scale-105 animate-[pulse_10s_ease-in-out_infinite]">
            <div class="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black"></div>
            <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent"></div>
        </div>

        <!-- Content -->
        <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-900/30 border border-blue-500/30 backdrop-blur-md mb-8 animate-[fadeInDown_1s_ease-out]">
                <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                <span class="text-xs font-semibold text-cyan-300 tracking-wide uppercase">Nueva Colección 2025</span>
            </div>
            
            <h1 class="text-5xl md:text-7xl lg:text-8xl font-extrabold text-white tracking-tight mb-8 leading-tight">
                Seguridad que <br>
                <span class="bg-gradient-to-r from-blue-400 via-cyan-300 to-teal-200 bg-clip-text text-transparent">te reconoce.</span>
            </h1>
            
            <p class="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed font-light">
                Eleva el estándar de tu hogar con cerraduras inteligentes de última generación. Reconocimiento facial 3D, control por app y diseño premium en cristal templado.
            </p>
            
            <div class="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <a href="#section-products" class="group relative px-8 py-4 bg-white text-black rounded-xl font-bold text-lg overflow-hidden transition-transform hover:scale-105">
                    <span class="absolute inset-0 bg-gradient-to-r from-cyan-300 to-blue-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                    <span class="relative z-10 group-hover:text-white transition-colors">Ver Catálogo</span>
                </a>
                <button class="px-8 py-4 rounded-xl bg-white/5 border border-white/10 text-white font-semibold hover:bg-white/10 transition-all backdrop-blur-sm flex items-center gap-3 group">
                    <i class="fa-solid fa-play text-xs p-2 rounded-full bg-white/10 group-hover:bg-cyan-500 group-hover:text-black transition-colors"></i>
                    Ver Demo
                </button>
            </div>
        </div>

        <!-- Scroll Indicator -->
        <div class="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
            <i class="fa-solid fa-chevron-down text-gray-500 text-xl"></i>
        </div>
    </section>

    <!-- Stats / Trust Strip -->
    <div id="block-stats" class="border-y border-white/5 bg-white/[0.02] backdrop-blur-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div class="space-y-2">
                    <div class="text-3xl md:text-4xl font-bold text-white">+50k</div>
                    <div class="text-sm text-gray-500 uppercase tracking-wider">Hogares Seguros</div>
                </div>
                <div class="space-y-2">
                    <div class="text-3xl md:text-4xl font-bold text-white">99.9%</div>
                    <div class="text-sm text-gray-500 uppercase tracking-wider">Uptime Servidor</div>
                </div>
                <div class="space-y-2">
                    <div class="text-3xl md:text-4xl font-bold text-white">24/7</div>
                    <div class="text-sm text-gray-500 uppercase tracking-wider">Soporte Técnico</div>
                </div>
                <div class="space-y-2">
                    <div class="text-3xl md:text-4xl font-bold text-white">2 Años</div>
                    <div class="text-sm text-gray-500 uppercase tracking-wider">Garantía Total</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Products Grid Section -->
    <section id="section-products" class="py-24 relative">
        <!-- Decorative Gradients -->
        <div class="absolute top-0 right-0 w-1/3 h-1/3 bg-blue-900/20 rounded-full blur-[120px] pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 w-1/3 h-1/3 bg-cyan-900/20 rounded-full blur-[120px] pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center mb-20">
                <h2 class="text-3xl md:text-5xl font-bold text-white mb-6">Nuestros Productos</h2>
                <p class="text-gray-400 max-w-2xl mx-auto">Tecnología de vanguardia diseñada para integrarse perfectamente con la estética de tu hogar u oficina.</p>
            </div>

            <!-- Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                <!-- Product Card 1: Zafe Os800 -->
                <div id="card-product-1" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="absolute top-4 right-4 z-20">
                        <span class="px-3 py-1 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-[10px] font-bold text-white uppercase tracking-wider shadow-lg">Premium</span>
                    </div>
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Os800" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Os800</h3>
                            <p class="text-xs text-gray-400 mb-4">Reconocimiento Facial 3D</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400" title="Face ID"><i class="fa-solid fa-face-smile"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400" title="Huella"><i class="fa-solid fa-fingerprint"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400" title="App"><i class="fa-solid fa-mobile-screen"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400" title="Cámara"><i class="fa-solid fa-video"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-xs text-gray-500 line-through">$ 1.500.000</p>
                                    <p class="text-lg font-bold text-white">$ 1.250.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-cyan-500 hover:bg-cyan-400 text-black flex items-center justify-center transition-colors shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 2: Zafe Vision Pro -->
                <div id="card-product-2" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="absolute top-4 right-4 z-20">
                        <span class="px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/50 text-[10px] font-bold text-blue-300 uppercase tracking-wider backdrop-blur-md">Cámara HD</span>
                    </div>
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/325111/pexels-photo-325111.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Vision Pro" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Vision Pro</h3>
                            <p class="text-xs text-gray-400 mb-4">Videoportero Integrado</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-video"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-wifi"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-microphone"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 980.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 3: Zafe BioTouch -->
                <div id="card-product-3" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe BioTouch" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe BioTouch</h3>
                            <p class="text-xs text-gray-400 mb-4">Huella Dactilar Ultra Rápida</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-fingerprint"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-key"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 750.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 4: Zafe Glass -->
                <div id="card-product-4" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="absolute top-4 right-4 z-20">
                        <span class="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-[10px] font-bold text-white uppercase tracking-wider backdrop-blur-md">Oficina</span>
                    </div>
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Glass" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Glass</h3>
                            <p class="text-xs text-gray-400 mb-4">Especial para Puertas de Vidrio</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-regular fa-building"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-table-cells"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 550.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 5: Zafe Rim Pro -->
                <div id="card-product-5" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Rim Pro" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Rim Pro</h3>
                            <p class="text-xs text-gray-400 mb-4">Cerradura de Sobreponer</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-shield"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-mobile"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 420.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 6: Zafe Handle -->
                <div id="card-product-6" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Handle" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Handle</h3>
                            <p class="text-xs text-gray-400 mb-4">Manija Inteligente Minimalista</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-grip-lines"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-brands fa-bluetooth"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 680.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 7: Zafe Deadbolt -->
                <div id="card-product-7" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/2760243/pexels-photo-2760243.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Deadbolt" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Deadbolt</h3>
                            <p class="text-xs text-gray-400 mb-4">Cerrojo de Alta Seguridad</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-lock"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-wifi"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 490.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Product Card 8: Zafe Gate -->
                <div id="card-product-8" class="group relative bg-gray-900/40 border border-white/10 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(6,182,212,0.2)]">
                    <div class="absolute top-4 right-4 z-20">
                        <span class="px-3 py-1 rounded-full bg-green-500/20 border border-green-500/50 text-[10px] font-bold text-green-300 uppercase tracking-wider backdrop-blur-md">Exterior</span>
                    </div>
                    <div class="h-64 overflow-hidden relative">
                        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                        <img src="https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Zafe Gate" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 relative z-20 -mt-12">
                        <div class="backdrop-blur-md bg-black/60 p-4 rounded-xl border border-white/5">
                            <h3 class="text-xl font-bold text-white mb-1">Zafe Gate</h3>
                            <p class="text-xs text-gray-400 mb-4">Resistente al Agua IP68</p>
                            
                            <div class="flex gap-2 mb-4 overflow-x-auto [&::-webkit-scrollbar]:hidden" style="scrollbar-width: none;">
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-cloud-rain"></i></div>
                                <div class="flex-shrink-0 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-cyan-400"><i class="fa-solid fa-solar-panel"></i></div>
                            </div>

                            <div class="flex items-end justify-between">
                                <div>
                                    <p class="text-lg font-bold text-white">$ 890.000 <span class="text-xs font-normal text-gray-400">COP</span></p>
                                </div>
                                <button class="w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-black flex items-center justify-center transition-all border border-white/20">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="section-features" class="py-24 bg-gradient-to-b from-black via-gray-900/50 to-black relative overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div class="space-y-8">
                    <h2 class="text-4xl md:text-5xl font-bold text-white leading-tight">
                        Control total desde <br>
                        <span class="text-cyan-400">la palma de tu mano.</span>
                    </h2>
                    <p class="text-gray-400 text-lg">
                        Nuestra app ZAFE Connect te permite gestionar accesos, ver historiales y generar llaves temporales desde cualquier lugar del mundo.
                    </p>
                    
                    <div class="space-y-6">
                        <div class="flex items-start gap-4">
                            <div class="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20">
                                <i class="fa-solid fa-share-nodes text-xl"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Llaves Temporales</h4>
                                <p class="text-gray-500 text-sm">Envía códigos de acceso que expiran automáticamente para invitados o servicios.</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 border border-purple-500/20">
                                <i class="fa-solid fa-bell text-xl"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Notificaciones en Vivo</h4>
                                <p class="text-gray-500 text-sm">Recibe alertas instantáneas cuando alguien entra a tu hogar o intenta forzar la cerradura.</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center text-green-400 border border-green-500/20">
                                <i class="fa-solid fa-battery-full text-xl"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Batería de Larga Duración</h4>
                                <p class="text-gray-500 text-sm">Hasta 12 meses de autonomía con aviso preventivo de batería baja.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="relative">
                    <div class="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl blur-2xl opacity-20 animate-pulse"></div>
                    <div class="relative bg-gray-900 border border-white/10 rounded-3xl p-2 shadow-2xl">
                        <img src="https://images.pexels.com/photos/205926/pexels-photo-205926.jpeg?auto=compress&cs=tinysrgb&w=800" alt="App Interface" class="rounded-2xl w-full object-cover h-[600px] opacity-90">
                        
                        <!-- Floating UI Elements -->
                        <div class="absolute top-10 -left-10 bg-black/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl shadow-2xl animate-[bounce_3s_infinite]">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                                <div>
                                    <p class="text-white text-sm font-bold">Puerta Cerrada</p>
                                    <p class="text-gray-500 text-xs">Hace 2 min</p>
                                </div>
                            </div>
                        </div>

                        <div class="absolute bottom-20 -right-10 bg-black/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl shadow-2xl animate-[bounce_4s_infinite]">
                            <div class="flex items-center gap-3">
                                <img src="https://i.pravatar.cc/150?u=33" class="w-10 h-10 rounded-full border-2 border-cyan-500" alt="User">
                                <div>
                                    <p class="text-white text-sm font-bold">Acceso Concedido</p>
                                    <p class="text-gray-500 text-xs">María G.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section id="section-testimonials" class="py-24 bg-black relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-white mb-4">Lo que dicen nuestros clientes</h2>
                <div class="w-20 h-1 bg-gradient-to-r from-blue-500 to-cyan-400 mx-auto rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Review 1 -->
                <div class="bg-white/5 border border-white/5 p-8 rounded-2xl relative">
                    <i class="fa-solid fa-quote-right absolute top-8 right-8 text-4xl text-white/5"></i>
                    <div class="flex items-center gap-4 mb-6">
                        <img src="https://i.pravatar.cc/150?u=12" alt="User" class="w-12 h-12 rounded-full border border-white/20">
                        <div>
                            <h4 class="text-white font-bold">Carlos Rodríguez</h4>
                            <p class="text-cyan-400 text-xs">Arquitecto</p>
                        </div>
                    </div>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        "Instalé la Zafe Os800 en mi oficina y la experiencia ha sido increíble. El reconocimiento facial es instantáneo y el diseño encaja perfecto con nuestra estética moderna."
                    </p>
                    <div class="flex gap-1 text-yellow-500 text-xs mt-4">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                </div>

                <!-- Review 2 -->
                <div class="bg-gradient-to-b from-white/10 to-white/5 border border-white/10 p-8 rounded-2xl relative transform md:-translate-y-4 shadow-2xl shadow-cyan-900/20">
                    <i class="fa-solid fa-quote-right absolute top-8 right-8 text-4xl text-white/5"></i>
                    <div class="flex items-center gap-4 mb-6">
                        <img src="https://i.pravatar.cc/150?u=45" alt="User" class="w-12 h-12 rounded-full border border-white/20">
                        <div>
                            <h4 class="text-white font-bold">Ana María Vélez</h4>
                            <p class="text-cyan-400 text-xs">Propietaria Airbnb</p>
                        </div>
                    </div>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        "Gestionar mis propiedades de Airbnb nunca fue tan fácil. Genero códigos temporales desde mi casa y me olvido de entregar llaves físicas. Servicio 10/10."
                    </p>
                    <div class="flex gap-1 text-yellow-500 text-xs mt-4">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                </div>

                <!-- Review 3 -->
                <div class="bg-white/5 border border-white/5 p-8 rounded-2xl relative">
                    <i class="fa-solid fa-quote-right absolute top-8 right-8 text-4xl text-white/5"></i>
                    <div class="flex items-center gap-4 mb-6">
                        <img src="https://i.pravatar.cc/150?u=67" alt="User" class="w-12 h-12 rounded-full border border-white/20">
                        <div>
                            <h4 class="text-white font-bold">Felipe Torres</h4>
                            <p class="text-cyan-400 text-xs">Ingeniero de Sistemas</p>
                        </div>
                    </div>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        "La integración con Alexa y Google Home funciona de maravilla. La calidad de construcción de la Zafe Deadbolt se siente muy robusta y segura."
                    </p>
                    <div class="flex gap-1 text-yellow-500 text-xs mt-4">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section id="section-cta" class="py-24 relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-r from-blue-900/40 to-cyan-900/40"></div>
        <img src="https://images.pexels.com/photos/323705/pexels-photo-323705.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Background" class="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay">
        
        <div class="max-w-4xl mx-auto px-4 relative z-10 text-center">
            <h2 class="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">¿Listo para modernizar tu seguridad?</h2>
            <p class="text-xl text-gray-300 mb-10 font-light">Agenda una visita técnica gratuita y descubre cuál es la cerradura ideal para tu puerta.</p>
            
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="px-8 py-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_30px_rgba(6,182,212,0.6)] transform hover:-translate-y-1">
                    Cotizar Ahora
                </button>
                <button class="px-8 py-4 bg-transparent border border-white/30 text-white font-bold rounded-xl hover:bg-white/10 transition-all backdrop-blur-sm">
                    Hablar con Asesor
                </button>
            </div>
        </div>
    </section>

</main>

<footer id="footer-main" class="bg-black border-t border-white/10 pt-20 pb-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <!-- Brand -->
            <div class="space-y-6">
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-shield-halved text-cyan-400 text-2xl"></i>
                    <span class="text-2xl font-bold text-white">ZAFESYS</span>
                </div>
                <p class="text-gray-400 text-sm leading-relaxed">
                    Líderes en soluciones de seguridad inteligente en Colombia. Transformamos accesos tradicionales en experiencias tecnológicas seguras.
                </p>
                <div class="flex gap-4">
                    <a href="#" class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-cyan-500 hover:text-black transition-all"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-cyan-500 hover:text-black transition-all"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-cyan-500 hover:text-black transition-all"><i class="fa-brands fa-linkedin-in"></i></a>
                </div>
            </div>

            <!-- Links -->
            <div>
                <h4 class="text-white font-bold mb-6">Productos</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Cerraduras Faciales</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Cerraduras con Cámara</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Para Vidrio</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Accesorios</a></li>
                </ul>
            </div>

            <!-- Links -->
            <div>
                <h4 class="text-white font-bold mb-6">Compañía</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Sobre Nosotros</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Blog de Seguridad</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Instaladores</a></li>
                    <li><a href="#" class="hover:text-cyan-400 transition-colors">Contacto</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div>
                <h4 class="text-white font-bold mb-6">Contacto</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li class="flex items-start gap-3">
                        <i class="fa-solid fa-location-dot mt-1 text-cyan-500"></i>
                        <span>Calle 93 # 15-40, Of 302<br>Bogotá, Colombia</span>
                    </li>
                    <li class="flex items-center gap-3">
                        <i class="fa-solid fa-phone text-cyan-500"></i>
                        <span>+57 (601) 555-0123</span>
                    </li>
                    <li class="flex items-center gap-3">
                        <i class="fa-solid fa-envelope text-cyan-500"></i>
                        <span>ventas@zafesys.com</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p class="text-gray-500 text-sm">© 2025 ZAFESYS Colombia. Todos los derechos reservados.</p>
            <div class="flex gap-6 text-sm text-gray-500">
                <a href="#" class="hover:text-white transition-colors">Privacidad</a>
                <a href="#" class="hover:text-white transition-colors">Términos</a>
            </div>
        </div>
    </div>
</footer>

<!-- WhatsApp Floating Button -->
<a href="https://wa.me/" target="_blank" class="fixed bottom-6 right-6 z-50 group">
    <span class="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-white text-black text-xs font-bold px-3 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg">¡Chatea con nosotros!</span>
    <div class="bg-green-500 hover:bg-green-400 text-white p-4 rounded-full shadow-[0_0_20px_rgba(34,197,94,0.5)] transition-all transform hover:scale-110 hover:rotate-12 flex items-center justify-center w-14 h-14">
        <i class="fa-brands fa-whatsapp text-2xl"></i>
    </div>
</a>