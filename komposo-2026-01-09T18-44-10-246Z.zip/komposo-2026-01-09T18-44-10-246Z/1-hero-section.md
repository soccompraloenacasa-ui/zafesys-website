Convert the below HTML/CSS code into React component. Do not include the global components as these already exist:

<style>
    @keyframes float {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-20px); }
    }
    @keyframes pulse-glow {
        0%, 100% { opacity: 0.5; transform: scale(1); }
        50% { opacity: 0.8; transform: scale(1.05); }
    }
    @keyframes scan-line {
        0% { top: 0%; opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { top: 100%; opacity: 0; }
    }
    @keyframes fade-in-up {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes ken-burns {
        0% { transform: scale(1); }
        100% { transform: scale(1.1); }
    }
    .animate-float { animation: float 6s ease-in-out infinite; }
    .animate-pulse-glow { animation: pulse-glow 4s ease-in-out infinite; }
    .animate-scan { animation: scan-line 3s linear infinite; }
    .animate-fade-in { animation: fade-in-up 1s ease-out forwards; }
    .animate-ken-burns { animation: ken-burns 20s ease-out infinite alternate; }
    
    .glass-panel {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .text-gradient {
        background: linear-gradient(135deg, #60a5fa 0%, #22d3ee 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar { width: 8px; }
    ::-webkit-scrollbar-track { background: #000; }
    ::-webkit-scrollbar-thumb { background: #333; border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: #444; }
</style>

<!-- Navigation -->
<nav id="header-main" class="fixed top-0 w-full z-50 transition-all duration-300 bg-black/50 backdrop-blur-xl border-b border-white/5">
    <div class="max-w-7xl mx-auto px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
            <!-- Logo -->
            <div class="flex-shrink-0 flex items-center gap-3 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:shadow-blue-500/40 transition-all">
                    <i class="fa-solid fa-shield-halved text-white text-lg"></i>
                </div>
                <span class="text-2xl font-bold tracking-tight text-white">ZAFESYS</span>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex items-center gap-8">
                <a href="#section-features" class="text-sm font-medium text-gray-300 hover:text-white transition-colors">Características</a>
                <a href="#section-technology" class="text-sm font-medium text-gray-300 hover:text-white transition-colors">Tecnología</a>
                <a href="#section-app" class="text-sm font-medium text-gray-300 hover:text-white transition-colors">App</a>
                <a href="#section-pricing" class="text-sm font-medium text-gray-300 hover:text-white transition-colors">Precios</a>
            </div>

            <!-- CTA Button -->
            <div class="hidden md:flex items-center gap-4">
                <a href="#section-pricing" class="group relative px-6 py-2.5 rounded-full bg-white text-black font-semibold text-sm overflow-hidden transition-all hover:bg-gray-100 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]">
                    <span class="relative z-10">Comprar Ahora</span>
                </a>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button class="text-gray-300 hover:text-white">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
            </div>
        </div>
    </div>
</nav>

<main id="main-content" class="relative">

    <!-- HERO SECTION -->
    <section id="section-hero" class="relative h-screen w-full overflow-hidden flex items-center justify-center bg-black">
        <!-- Animated Background Layer -->
        <div class="absolute inset-0 z-0">
            <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black z-10"></div>
            <!-- Using a high-quality architectural image to simulate the environment -->
            <img src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920" 
                 alt="Modern Home Entrance" 
                 class="w-full h-full object-cover animate-ken-burns opacity-60">
        </div>

        <!-- Hero Content -->
        <div class="relative z-20 max-w-7xl mx-auto px-6 lg:px-8 w-full grid lg:grid-cols-2 gap-12 items-center">
            
            <!-- Text Content -->
            <div class="space-y-8 text-center lg:text-left pt-20 lg:pt-0">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-medium uppercase tracking-wider animate-fade-in" style="animation-delay: 0.1s;">
                    <span class="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
                    Nueva Generación 2025
                </div>
                
                <h1 class="text-5xl lg:text-7xl font-bold text-white leading-tight tracking-tight animate-fade-in" style="animation-delay: 0.2s;">
                    Seguridad que <br>
                    <span class="text-gradient">te reconoce.</span>
                </h1>
                
                <p class="text-lg text-gray-400 max-w-xl mx-auto lg:mx-0 leading-relaxed animate-fade-in" style="animation-delay: 0.3s;">
                    ZAFESYS transforma tu puerta en una fortaleza inteligente. Acceso biométrico, reconocimiento facial y control total desde tu smartphone.
                </p>
                
                <div class="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start animate-fade-in" style="animation-delay: 0.4s;">
                    <button class="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2">
                        Ver Modelos
                        <i class="fa-solid fa-arrow-right"></i>
                    </button>
                    <button class="w-full sm:w-auto px-8 py-4 rounded-xl glass-panel text-white font-semibold hover:bg-white/10 transition-all duration-300 flex items-center justify-center gap-2">
                        <i class="fa-solid fa-play text-blue-400"></i>
                        Ver Demo
                    </button>
                </div>

                <!-- Trust Indicators -->
                <div class="pt-8 flex items-center justify-center lg:justify-start gap-6 text-gray-500 animate-fade-in" style="animation-delay: 0.5s;">
                    <div class="flex items-center gap-2">
                        <i class="fa-solid fa-shield-check text-blue-500"></i>
                        <span class="text-sm">Grado Militar</span>
                    </div>
                    <div class="w-px h-4 bg-gray-800"></div>
                    <div class="flex items-center gap-2">
                        <i class="fa-solid fa-wifi text-blue-500"></i>
                        <span class="text-sm">Conexión 24/7</span>
                    </div>
                    <div class="w-px h-4 bg-gray-800"></div>
                    <div class="flex items-center gap-2">
                        <i class="fa-solid fa-battery-full text-blue-500"></i>
                        <span class="text-sm">1 Año Batería</span>
                    </div>
                </div>
            </div>

            <!-- Visual/Lock Overlay -->
            <div class="relative hidden lg:block h-[600px] w-full animate-fade-in" style="animation-delay: 0.4s;">
                <!-- Glow Effect -->
                <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-500/20 rounded-full blur-[100px] animate-pulse-glow"></div>
                
                <!-- Lock Image Container -->
                <div class="absolute inset-0 flex items-center justify-center animate-float">
                    <div class="relative w-[320px] h-[580px] bg-black rounded-[40px] border-4 border-gray-800 shadow-2xl overflow-hidden group">
                        <!-- Screen/Interface Simulation -->
                        <div class="absolute inset-0 bg-gray-900">
                            <!-- Header -->
                            <div class="h-24 bg-gradient-to-b from-gray-800 to-gray-900 flex flex-col items-center justify-center border-b border-gray-700">
                                <div class="w-16 h-16 rounded-full border-2 border-blue-500/50 flex items-center justify-center relative">
                                    <i class="fa-solid fa-camera text-blue-400 text-xl"></i>
                                    <!-- Scanning Effect -->
                                    <div class="absolute inset-0 border-t-2 border-blue-400 rounded-full animate-spin" style="animation-duration: 3s;"></div>
                                </div>
                            </div>
                            
                            <!-- Keypad Area -->
                            <div class="p-8 grid grid-cols-3 gap-4 mt-8">
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">1</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">2</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">3</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">4</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">5</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">6</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">7</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">8</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">9</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">*</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">0</div>
                                <div class="h-16 rounded-full bg-gray-800/50 flex items-center justify-center text-white text-xl font-light hover:bg-blue-500/20 hover:text-blue-400 transition-colors cursor-pointer">#</div>
                            </div>

                            <!-- Handle Area -->
                            <div class="absolute bottom-0 w-full h-32 bg-gradient-to-t from-black to-transparent flex items-center justify-center">
                                <div class="w-48 h-12 rounded-full bg-gray-800 border border-gray-700 flex items-center justify-center gap-2 shadow-lg">
                                    <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                                    <span class="text-xs text-gray-400 uppercase tracking-widest">Locked</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Reflection Overlay -->
                        <div class="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none"></div>
                    </div>
                    
                    <!-- Floating Elements -->
                    <div class="absolute top-20 -right-12 glass-panel p-4 rounded-2xl flex items-center gap-3 animate-bounce" style="animation-duration: 3s;">
                        <div class="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400">
                            <i class="fa-solid fa-check"></i>
                        </div>
                        <div>
                            <div class="text-xs text-gray-400">Estado</div>
                            <div class="text-sm font-bold text-white">Seguro</div>
                        </div>
                    </div>

                    <div class="absolute bottom-32 -left-12 glass-panel p-4 rounded-2xl flex items-center gap-3 animate-bounce" style="animation-duration: 4s;">
                        <div class="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                            <i class="fa-solid fa-fingerprint"></i>
                        </div>
                        <div>
                            <div class="text-xs text-gray-400">Acceso</div>
                            <div class="text-sm font-bold text-white">Biométrico</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50 animate-bounce">
            <span class="text-xs text-gray-400 uppercase tracking-widest">Descubre más</span>
            <i class="fa-solid fa-chevron-down text-white"></i>
        </div>
    </section>

    <!-- LOGO CLOUD -->
    <section class="py-10 bg-black border-y border-white/5">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <p class="text-center text-sm text-gray-500 mb-8">INTEGRACIÓN NATIVA CON LOS MEJORES ECOSISTEMAS</p>
            <div class="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
                <div class="flex items-center gap-2 text-xl font-bold text-white"><i class="fa-brands fa-apple text-2xl"></i> HomeKit</div>
                <div class="flex items-center gap-2 text-xl font-bold text-white"><i class="fa-brands fa-google text-2xl"></i> Home</div>
                <div class="flex items-center gap-2 text-xl font-bold text-white"><i class="fa-brands fa-amazon text-2xl"></i> Alexa</div>
                <div class="flex items-center gap-2 text-xl font-bold text-white"><i class="fa-solid fa-house-signal text-2xl"></i> SmartThings</div>
            </div>
        </div>
    </section>

    <!-- FEATURES BENTO GRID -->
    <section id="section-features" class="py-24 bg-black relative">
        <div class="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-900/20 via-black to-black pointer-events-none"></div>
        
        <div class="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div class="text-center max-w-3xl mx-auto mb-20">
                <h2 class="text-3xl md:text-5xl font-bold text-white mb-6">Tecnología que protege <br>lo que más importa</h2>
                <p class="text-gray-400 text-lg">Diseñado con precisión para ofrecer seguridad sin fricción. Cada detalle ha sido pensado para tu tranquilidad.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Feature 1: Biometric (Large) -->
                <div class="md:col-span-2 rounded-3xl glass-panel p-8 md:p-12 relative overflow-hidden group min-h-[400px] flex flex-col justify-end">
                    <div class="absolute inset-0 bg-gradient-to-b from-transparent to-black/90 z-10"></div>
                    <img src="https://images.pexels.com/photos/5499547/pexels-photo-5499547.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Fingerprint" class="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60">
                    
                    <div class="relative z-20">
                        <div class="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center mb-6 shadow-lg shadow-blue-600/30">
                            <i class="fa-solid fa-fingerprint text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-3">Reconocimiento Dactilar 3D</h3>
                        <p class="text-gray-300 max-w-md">Sensor capacitivo de última generación que desbloquea tu puerta en 0.3 segundos. Almacena hasta 100 huellas únicas.</p>
                    </div>
                </div>

                <!-- Feature 2: Camera -->
                <div class="rounded-3xl glass-panel p-8 relative overflow-hidden group min-h-[400px] flex flex-col justify-between">
                    <div class="absolute top-0 right-0 p-8 opacity-20 group-hover:opacity-40 transition-opacity">
                        <i class="fa-solid fa-eye text-8xl text-cyan-400"></i>
                    </div>
                    
                    <div class="relative z-20 mt-auto">
                        <div class="w-12 h-12 rounded-xl bg-cyan-900/50 border border-cyan-500/30 flex items-center justify-center mb-4">
                            <i class="fa-solid fa-video text-cyan-400"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-2">Visión HD Nocturna</h3>
                        <p class="text-gray-400 text-sm">Cámara 1080p integrada con visión nocturna por infrarrojos para ver quién llama, día y noche.</p>
                    </div>
                </div>

                <!-- Feature 3: App Control -->
                <div class="rounded-3xl glass-panel p-8 relative overflow-hidden group min-h-[300px] flex flex-col justify-between">
                    <div class="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-transparent"></div>
                    <div class="relative z-20">
                        <div class="w-12 h-12 rounded-xl bg-purple-900/50 border border-purple-500/30 flex items-center justify-center mb-4">
                            <i class="fa-solid fa-mobile-screen text-purple-400"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-2">Control Remoto Total</h3>
                        <p class="text-gray-400 text-sm">Abre la puerta desde la oficina o crea llaves temporales para invitados desde la app Zafesys.</p>
                    </div>
                    <div class="absolute bottom-4 right-4 w-32 h-32 bg-purple-500/20 rounded-full blur-3xl"></div>
                </div>

                <!-- Feature 4: Battery (Large) -->
                <div class="md:col-span-2 rounded-3xl glass-panel p-8 md:p-12 relative overflow-hidden group min-h-[300px] flex items-center">
                    <div class="grid md:grid-cols-2 gap-8 items-center w-full relative z-20">
                        <div>
                            <div class="w-12 h-12 rounded-xl bg-green-900/50 border border-green-500/30 flex items-center justify-center mb-6">
                                <i class="fa-solid fa-battery-full text-green-400"></i>
                            </div>
                            <h3 class="text-2xl font-bold text-white mb-3">Energía para 12 Meses</h3>
                            <p class="text-gray-300">Olvídate de las recargas constantes. Nuestra tecnología de bajo consumo garantiza un año completo de uso con una sola carga.</p>
                        </div>
                        <div class="flex justify-center">
                            <div class="relative w-full max-w-xs h-32 bg-gray-800 rounded-2xl border border-gray-700 p-4 flex items-center gap-4">
                                <div class="flex-1 h-12 bg-gray-900 rounded-lg overflow-hidden relative">
                                    <div class="absolute top-0 left-0 h-full bg-gradient-to-r from-green-600 to-green-400 w-[92%]"></div>
                                    <div class="absolute inset-0 flex items-center justify-center text-white font-mono text-sm font-bold">92%</div>
                                </div>
                                <i class="fa-solid fa-bolt text-yellow-400 text-xl animate-pulse"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- IMMERSIVE APP SECTION -->
    <section id="section-app" class="py-32 bg-black relative overflow-hidden">
        <!-- Decorative Elements -->
        <div class="absolute top-1/2 left-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] -translate-y-1/2"></div>
        <div class="absolute bottom-0 right-0 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[120px]"></div>

        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <!-- Phone Mockup -->
                <div class="relative mx-auto lg:mx-0 order-2 lg:order-1">
                    <div class="relative w-[300px] h-[600px] bg-gray-900 rounded-[40px] border-[8px] border-gray-800 shadow-2xl overflow-hidden mx-auto">
                        <!-- Notch -->
                        <div class="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-gray-800 rounded-b-xl z-30"></div>
                        
                        <!-- App Screen -->
                        <div class="w-full h-full bg-gray-900 relative">
                            <!-- App Header -->
                            <div class="pt-12 px-6 pb-6 bg-gradient-to-b from-gray-800 to-gray-900">
                                <div class="flex justify-between items-center mb-6">
                                    <div class="text-white font-bold text-lg">Mi Casa</div>
                                    <div class="w-8 h-8 rounded-full bg-gray-700"></div>
                                </div>
                                <div class="text-gray-400 text-sm">Estado Actual</div>
                                <div class="text-3xl font-bold text-white flex items-center gap-2">
                                    <span class="w-3 h-3 rounded-full bg-green-500"></span>
                                    Cerrado
                                </div>
                            </div>

                            <!-- Camera Feed Placeholder -->
                            <div class="h-48 bg-gray-800 relative overflow-hidden group">
                                <img src="https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=400" class="w-full h-full object-cover opacity-50" alt="Camera Feed">
                                <div class="absolute top-2 right-2 bg-red-500 text-white text-[10px] px-2 py-0.5 rounded animate-pulse">LIVE</div>
                                <div class="absolute inset-0 flex items-center justify-center">
                                    <div class="w-12 h-12 rounded-full bg-white/20 backdrop-blur flex items-center justify-center cursor-pointer hover:scale-110 transition">
                                        <i class="fa-solid fa-play text-white"></i>
                                    </div>
                                </div>
                            </div>

                            <!-- Actions -->
                            <div class="p-6 grid grid-cols-2 gap-4">
                                <div class="bg-blue-600 rounded-xl p-4 text-white flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-blue-500 transition">
                                    <i class="fa-solid fa-lock-open text-2xl"></i>
                                    <span class="text-xs font-bold">Abrir</span>
                                </div>
                                <div class="bg-gray-800 rounded-xl p-4 text-gray-300 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-700 transition">
                                    <i class="fa-solid fa-key text-2xl"></i>
                                    <span class="text-xs font-bold">eKey</span>
                                </div>
                                <div class="bg-gray-800 rounded-xl p-4 text-gray-300 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-700 transition">
                                    <i class="fa-solid fa-clock-rotate-left text-2xl"></i>
                                    <span class="text-xs font-bold">Historial</span>
                                </div>
                                <div class="bg-gray-800 rounded-xl p-4 text-gray-300 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-700 transition">
                                    <i class="fa-solid fa-gear text-2xl"></i>
                                    <span class="text-xs font-bold">Ajustes</span>
                                </div>
                            </div>
                            
                            <!-- Notification Pop -->
                            <div class="absolute bottom-6 left-4 right-4 bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10 flex items-center gap-3 animate-fade-in" style="animation-delay: 2s;">
                                <div class="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs">
                                    <i class="fa-solid fa-bell"></i>
                                </div>
                                <div>
                                    <div class="text-xs text-white font-bold">Movimiento Detectado</div>
                                    <div class="text-[10px] text-gray-300">Puerta Principal • Hace 2 min</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Content -->
                <div class="order-1 lg:order-2">
                    <h2 class="text-4xl font-bold text-white mb-6">Tu hogar en la palma de tu mano</h2>
                    <p class="text-gray-400 text-lg mb-8 leading-relaxed">
                        La aplicación ZAFESYS es el centro de comando de tu seguridad. Recibe notificaciones instantáneas, visualiza quién está en tu puerta en tiempo real y gestiona accesos desde cualquier lugar del mundo.
                    </p>
                    
                    <div class="space-y-6">
                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center mt-1">
                                <i class="fa-solid fa-share-nodes text-blue-400"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Llaves Temporales</h4>
                                <p class="text-gray-500 text-sm mt-1">Envía códigos de acceso que expiran automáticamente para invitados o servicios.</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center mt-1">
                                <i class="fa-solid fa-shield-cat text-blue-400"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Registro de Actividad</h4>
                                <p class="text-gray-500 text-sm mt-1">Historial detallado de quién entró y salió, con fecha, hora y método de acceso.</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center mt-1">
                                <i class="fa-solid fa-bell text-blue-400"></i>
                            </div>
                            <div>
                                <h4 class="text-white font-bold text-lg">Alertas Inteligentes</h4>
                                <p class="text-gray-500 text-sm mt-1">Detección de intentos forzados o puerta mal cerrada con notificación inmediata.</p>
                            </div>
                        </div>
                    </div>

                    <div class="mt-10 flex gap-4">
                        <button class="px-6 py-3 rounded-lg bg-white text-black font-bold hover:bg-gray-200 transition flex items-center gap-2">
                            <i class="fa-brands fa-apple text-xl"></i> App Store
                        </button>
                        <button class="px-6 py-3 rounded-lg border border-gray-700 text-white font-bold hover:bg-gray-800 transition flex items-center gap-2">
                            <i class="fa-brands fa-google-play text-xl"></i> Google Play
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- TESTIMONIALS -->
    <section id="section-testimonials" class="py-24 bg-gray-900 border-y border-white/5">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-white text-center mb-16">Confianza que se siente</h2>
            
            <div class="grid md:grid-cols-3 gap-8">
                <!-- Review 1 -->
                <div class="bg-black p-8 rounded-2xl border border-gray-800 relative">
                    <div class="flex text-yellow-500 mb-4 text-sm">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 leading-relaxed">"La instalación fue increíblemente sencilla. La función de reconocimiento facial es tan rápida que ni siquiera tengo que detenerme al entrar a casa."</p>
                    <div class="flex items-center gap-4">
                        <img src="https://i.pravatar.cc/150?u=1" alt="User" class="w-10 h-10 rounded-full">
                        <div>
                            <div class="text-white font-bold text-sm">Carlos Mendoza</div>
                            <div class="text-gray-500 text-xs">Arquitecto</div>
                        </div>
                    </div>
                </div>

                <!-- Review 2 -->
                <div class="bg-black p-8 rounded-2xl border border-gray-800 relative transform md:-translate-y-4 shadow-xl shadow-blue-900/10">
                    <div class="flex text-yellow-500 mb-4 text-sm">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 leading-relaxed">"Gestionar los accesos de mi Airbnb nunca fue tan fácil. Genero códigos temporales desde la app y me olvido de entregar llaves físicas."</p>
                    <div class="flex items-center gap-4">
                        <img src="https://i.pravatar.cc/150?u=2" alt="User" class="w-10 h-10 rounded-full">
                        <div>
                            <div class="text-white font-bold text-sm">Ana Torres</div>
                            <div class="text-gray-500 text-xs">Host de Airbnb</div>
                        </div>
                    </div>
                </div>

                <!-- Review 3 -->
                <div class="bg-black p-8 rounded-2xl border border-gray-800 relative">
                    <div class="flex text-yellow-500 mb-4 text-sm">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 leading-relaxed">"La calidad de construcción es premium. Se siente sólida y segura. La integración con Alexa funciona a la perfección para cerrar por las noches."</p>
                    <div class="flex items-center gap-4">
                        <img src="https://i.pravatar.cc/150?u=3" alt="User" class="w-10 h-10 rounded-full">
                        <div>
                            <div class="text-white font-bold text-sm">Roberto Gil</div>
                            <div class="text-gray-500 text-xs">Ingeniero de Software</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- PRICING -->
    <section id="section-pricing" class="py-24 bg-black relative">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-5xl font-bold text-white mb-4">Elige tu nivel de seguridad</h2>
                <p class="text-gray-400">Planes simples, sin cuotas mensuales ocultas.</p>
            </div>

            <div class="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                <!-- Basic -->
                <div class="rounded-3xl border border-gray-800 bg-gray-900/50 p-8 flex flex-col hover:border-gray-600 transition duration-300">
                    <div class="mb-4">
                        <h3 class="text-xl font-bold text-white">Zafesys Core</h3>
                        <p class="text-gray-400 text-sm mt-2">Seguridad esencial inteligente.</p>
                    </div>
                    <div class="mb-6">
                        <span class="text-4xl font-bold text-white">$199</span>
                    </div>
                    <ul class="space-y-4 mb-8 flex-1">
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Teclado Numérico</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> App Bluetooth</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Llaves Físicas (2)</li>
                        <li class="flex items-center gap-3 text-gray-500 text-sm"><i class="fa-solid fa-xmark"></i> Conexión WiFi (Requiere Hub)</li>
                    </ul>
                    <button class="w-full py-3 rounded-xl border border-gray-600 text-white font-semibold hover:bg-white hover:text-black transition">Seleccionar</button>
                </div>

                <!-- Pro (Featured) -->
                <div class="rounded-3xl border-2 border-blue-500 bg-gray-900 p-8 flex flex-col relative transform md:-translate-y-4 shadow-2xl shadow-blue-900/20">
                    <div class="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wide">Más Vendido</div>
                    <div class="mb-4">
                        <h3 class="text-xl font-bold text-white">Zafesys Pro</h3>
                        <p class="text-gray-400 text-sm mt-2">Biometría y control total.</p>
                    </div>
                    <div class="mb-6">
                        <span class="text-4xl font-bold text-white">$299</span>
                    </div>
                    <ul class="space-y-4 mb-8 flex-1">
                        <li class="flex items-center gap-3 text-white text-sm"><i class="fa-solid fa-check text-blue-400"></i> <strong>Todo en Core +</strong></li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Lector de Huella 3D</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> WiFi Integrado</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Notificaciones Remotas</li>
                    </ul>
                    <button class="w-full py-3 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-500 transition shadow-lg shadow-blue-600/25">Comprar Ahora</button>
                </div>

                <!-- Elite -->
                <div class="rounded-3xl border border-gray-800 bg-gray-900/50 p-8 flex flex-col hover:border-gray-600 transition duration-300">
                    <div class="mb-4">
                        <h3 class="text-xl font-bold text-white">Zafesys Vision</h3>
                        <p class="text-gray-400 text-sm mt-2">Máxima seguridad con video.</p>
                    </div>
                    <div class="mb-6">
                        <span class="text-4xl font-bold text-white">$399</span>
                    </div>
                    <ul class="space-y-4 mb-8 flex-1">
                        <li class="flex items-center gap-3 text-white text-sm"><i class="fa-solid fa-check text-blue-400"></i> <strong>Todo en Pro +</strong></li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Cámara HD 1080p</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Audio Bidireccional</li>
                        <li class="flex items-center gap-3 text-gray-300 text-sm"><i class="fa-solid fa-check text-blue-500"></i> Reconocimiento Facial</li>
                    </ul>
                    <button class="w-full py-3 rounded-xl border border-gray-600 text-white font-semibold hover:bg-white hover:text-black transition">Seleccionar</button>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA FINAL -->
    <section id="section-cta" class="py-24 relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-r from-blue-900 to-black"></div>
        <div class="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
        
        <div class="max-w-4xl mx-auto px-6 lg:px-8 relative z-10 text-center">
            <h2 class="text-4xl md:text-6xl font-bold text-white mb-8">Protege tu mundo hoy.</h2>
            <p class="text-xl text-blue-100 mb-10">Únete a más de 50,000 hogares seguros con Zafesys. Envío gratis y garantía de 30 días.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="px-10 py-4 rounded-full bg-white text-blue-900 font-bold text-lg hover:bg-gray-100 transition shadow-xl">
                    Comprar Zafesys
                </button>
                <button class="px-10 py-4 rounded-full border border-white/30 text-white font-bold text-lg hover:bg-white/10 transition">
                    Contactar Ventas
                </button>
            </div>
        </div>
    </section>

</main>

<!-- Footer -->
<footer id="footer-main" class="bg-black border-t border-white/10 pt-20 pb-10">
    <div class="max-w-7xl mx-auto px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div>
                <div class="flex items-center gap-2 mb-6">
                    <div class="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                        <i class="fa-solid fa-shield-halved text-white text-sm"></i>
                    </div>
                    <span class="text-xl font-bold text-white">ZAFESYS</span>
                </div>
                <p class="text-gray-400 text-sm leading-relaxed">
                    Redefiniendo la seguridad del hogar con tecnología de vanguardia y diseño elegante. Tu tranquilidad es nuestra misión.
                </p>
            </div>
            
            <div>
                <h4 class="text-white font-bold mb-6">Productos</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-blue-400 transition">Zafesys Core</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Zafesys Pro</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Zafesys Vision</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Accesorios</a></li>
                </ul>
            </div>
            
            <div>
                <h4 class="text-white font-bold mb-6">Soporte</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-blue-400 transition">Centro de Ayuda</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Instalación</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Garantía</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Contacto</a></li>
                </ul>
            </div>
            
            <div>
                <h4 class="text-white font-bold mb-6">Legal</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="#" class="hover:text-blue-400 transition">Privacidad</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Términos de Uso</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition">Política de Cookies</a></li>
                </ul>
            </div>
        </div>
        
        <div class="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p class="text-gray-500 text-sm">© 2025 ZAFESYS Inc. Todos los derechos reservados.</p>
            <div class="flex gap-6">
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fa-brands fa-twitter text-xl"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fa-brands fa-instagram text-xl"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fa-brands fa-linkedin text-xl"></i></a>
                <a href="#" class="text-gray-400 hover:text-white transition"><i class="fa-brands fa-youtube text-xl"></i></a>
            </div>
        </div>
    </div>
</footer>

<!-- WhatsApp Floating Button -->
<a href="https://wa.me/" target="_blank" class="fixed bottom-6 right-6 z-50 bg-[#25D366] hover:bg-[#20ba5a] text-white p-4 rounded-full shadow-lg shadow-green-900/20 transition transform hover:scale-110 flex items-center justify-center group">
    <i class="fa-brands fa-whatsapp text-2xl"></i>
    <span class="absolute right-full mr-3 bg-white text-black text-xs font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition whitespace-nowrap pointer-events-none">Chatea con nosotros</span>
</a>