Convert the below HTML/CSS code into React component. Do not include the global components as these already exist:

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZAFESYS - Cerraduras Inteligentes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        .glass-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .text-gradient {
            background: linear-gradient(to right, #60a5fa, #22d3ee);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .glow-point {
            box-shadow: 0 0 20px 5px rgba(56, 189, 248, 0.3);
        }
    </style>
</head>
<body class="bg-black text-white overflow-x-hidden selection:bg-cyan-500 selection:text-black">

    <!-- Navbar (Placeholder for context, assuming user provided wrapper handles this, but including for standalone preview correctness if needed) -->
    <!-- Note: In the final output I will only provide the content inside main as requested, but the prompt implies I am generating the full page content to fit the wrapper provided in the prompt description. -->

    <main class="relative w-full overflow-hidden">
        
        <!-- Background Ambient Effects -->
        <div class="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
            <div class="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px] mix-blend-screen animate-pulse"></div>
            <div class="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[100px] mix-blend-screen"></div>
        </div>

        <!-- HERO SECTION: Mission & Vision -->
        <section id="section-hero" class="relative pt-20 pb-32 lg:pt-32 lg:pb-40 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <div class="space-y-8 relative z-10">
                    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/30 border border-blue-500/30 text-blue-400 text-xs font-medium tracking-wide uppercase">
                        <span class="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
                        Innovación en Seguridad
                    </div>
                    
                    <h1 class="text-5xl lg:text-7xl font-bold tracking-tight leading-tight">
                        Seguridad que <br>
                        <span class="text-gradient">Entiende tu Vida</span>
                    </h1>
                    
                    <p class="text-lg text-gray-400 leading-relaxed max-w-xl">
                        En <strong class="text-white">ZAFESYS</strong>, nuestra misión es redefinir el acceso. No solo vendemos cerraduras; diseñamos ecosistemas de seguridad inteligente que combinan encriptación de grado militar con una experiencia de usuario fluida y elegante.
                    </p>

                    <div class="flex flex-wrap gap-4 pt-4">
                        <a href="#section-services" class="group relative px-8 py-4 bg-white text-black font-bold rounded-xl overflow-hidden transition-all hover:scale-105">
                            <div class="absolute inset-0 w-full h-full bg-gradient-to-r from-blue-400 to-cyan-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                            <span class="relative z-10 flex items-center gap-2">
                                Explorar Servicios <i class="fa-solid fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                            </span>
                        </a>
                        <button class="px-8 py-4 rounded-xl border border-white/10 hover:bg-white/5 transition-colors font-medium text-gray-300 hover:text-white">
                            Conocer la Tecnología
                        </button>
                    </div>

                    <!-- Stats -->
                    <div class="grid grid-cols-3 gap-8 pt-12 border-t border-white/10">
                        <div>
                            <div class="text-3xl font-bold text-white">10k+</div>
                            <div class="text-sm text-gray-500 mt-1">Instalaciones</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-white">99.9%</div>
                            <div class="text-sm text-gray-500 mt-1">Uptime</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-white">24/7</div>
                            <div class="text-sm text-gray-500 mt-1">Soporte Activo</div>
                        </div>
                    </div>
                </div>

                <div class="relative lg:h-[600px] w-full">
                    <!-- Abstract Tech Visual -->
                    <div class="relative w-full h-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-blue-900/20 group">
                        <img src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Smart Home Security" class="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700">
                        <div class="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                        
                        <!-- Floating UI Elements simulating Smart Lock Interface -->
                        <div class="absolute bottom-10 left-10 right-10 p-6 glass-card rounded-xl border-t border-white/20 transform translate-y-0 transition-transform">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400">
                                        <i class="fa-solid fa-lock"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm font-semibold text-white">Puerta Principal</div>
                                        <div class="text-xs text-green-400">Cerrada • Batería 98%</div>
                                    </div>
                                </div>
                                <i class="fa-solid fa-wifi text-gray-500"></i>
                            </div>
                            <div class="h-1 w-full bg-gray-700 rounded-full overflow-hidden">
                                <div class="h-full w-full bg-green-500 rounded-full"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Decorative Elements -->
                    <div class="absolute -top-10 -right-10 w-32 h-32 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full blur-3xl opacity-20"></div>
                </div>
            </div>
        </section>

        <!-- ABOUT: Expertise & Philosophy -->
        <section id="section-about" class="py-24 bg-zinc-900/50 border-y border-white/5">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-20">
                    <h2 class="text-3xl md:text-4xl font-bold mb-6">Expertos en <span class="text-gradient">Acceso Inteligente</span></h2>
                    <p class="text-gray-400 text-lg">
                        ZAFESYS nació de la necesidad de modernizar la seguridad residencial y corporativa. Combinamos hardware robusto con software intuitivo para eliminar las llaves físicas y otorgar control total.
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-8">
                    <!-- Feature 1 -->
                    <div id="card-expertise-1" class="p-8 rounded-2xl bg-black border border-white/10 hover:border-blue-500/50 transition-colors duration-300 group">
                        <div class="w-14 h-14 rounded-xl bg-blue-900/20 flex items-center justify-center text-blue-400 mb-6 group-hover:scale-110 transition-transform">
                            <i class="fa-solid fa-fingerprint text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-white mb-3">Biometría Avanzada</h3>
                        <p class="text-gray-400 text-sm leading-relaxed">
                            Implementamos sensores de huella dactilar 3D y reconocimiento facial con detección de vida para evitar suplantaciones.
                        </p>
                    </div>

                    <!-- Feature 2 -->
                    <div id="card-expertise-2" class="p-8 rounded-2xl bg-black border border-white/10 hover:border-cyan-500/50 transition-colors duration-300 group">
                        <div class="w-14 h-14 rounded-xl bg-cyan-900/20 flex items-center justify-center text-cyan-400 mb-6 group-hover:scale-110 transition-transform">
                            <i class="fa-solid fa-shield-halved text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-white mb-3">Encriptación AES-256</h3>
                        <p class="text-gray-400 text-sm leading-relaxed">
                            Toda la comunicación entre tu dispositivo y la cerradura está protegida con los mismos estándares que la banca internacional.
                        </p>
                    </div>

                    <!-- Feature 3 -->
                    <div id="card-expertise-3" class="p-8 rounded-2xl bg-black border border-white/10 hover:border-purple-500/50 transition-colors duration-300 group">
                        <div class="w-14 h-14 rounded-xl bg-purple-900/20 flex items-center justify-center text-purple-400 mb-6 group-hover:scale-110 transition-transform">
                            <i class="fa-solid fa-mobile-screen-button text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-white mb-3">Control Total vía App</h3>
                        <p class="text-gray-400 text-sm leading-relaxed">
                            Gestiona accesos temporales, revisa historiales de entrada y recibe alertas en tiempo real desde cualquier lugar del mundo.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- SERVICES: The Core Offering -->
        <section id="section-services" class="py-32 relative">
            <!-- Background Pattern -->
            <div class="absolute inset-0 opacity-5" style="background-image: radial-gradient(#4b5563 1px, transparent 1px); background-size: 32px 32px;"></div>

            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div class="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
                    <div>
                        <span class="text-blue-500 font-semibold tracking-wider text-sm uppercase mb-2 block">Nuestros Servicios</span>
                        <h2 class="text-4xl md:text-5xl font-bold text-white">Soluciones Integrales <br>de <span class="text-gray-500">Ciclo Completo</span></h2>
                    </div>
                    <p class="text-gray-400 max-w-md text-sm md:text-base pb-2">
                        No solo vendemos el producto. Nos encargamos de todo el ciclo de vida de tu sistema de seguridad, desde la instalación hasta el soporte continuo.
                    </p>
                </div>

                <div class="grid lg:grid-cols-3 gap-6">
                    
                    <!-- Service Card 1: Installation -->
                    <article id="card-service-install" class="group relative h-[480px] rounded-3xl overflow-hidden border border-white/10 bg-zinc-900">
                        <div class="absolute inset-0">
                            <img src="https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Installation" class="w-full h-full object-cover opacity-40 group-hover:opacity-20 transition-opacity duration-500 grayscale group-hover:grayscale-0">
                            <div class="absolute inset-0 bg-gradient-to-b from-transparent via-black/80 to-black"></div>
                        </div>
                        
                        <div class="absolute inset-0 p-8 flex flex-col justify-end">
                            <div class="mb-auto transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                <span class="inline-block px-3 py-1 rounded-full bg-blue-600 text-white text-xs font-bold mb-4">PASO 1</span>
                            </div>
                            
                            <div class="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-2xl mb-6 shadow-lg shadow-blue-600/30 group-hover:scale-110 transition-transform duration-300">
                                <i class="fa-solid fa-screwdriver-wrench"></i>
                            </div>
                            
                            <h3 class="text-2xl font-bold text-white mb-3">Instalación Profesional</h3>
                            <p class="text-gray-400 text-sm mb-6 opacity-80 group-hover:opacity-100 transition-opacity">
                                Nuestros técnicos certificados realizan una instalación limpia y sin daños a tu puerta. Configuramos la red, calibramos los sensores y aseguramos un cierre perfecto.
                            </p>
                            
                            <ul class="space-y-2 text-sm text-gray-300 border-t border-white/10 pt-4">
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-blue-500 text-xs"></i> Evaluación de compatibilidad</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-blue-500 text-xs"></i> Configuración Wi-Fi/Bluetooth</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-blue-500 text-xs"></i> Capacitación de uso in-situ</li>
                            </ul>
                        </div>
                    </article>

                    <!-- Service Card 2: Maintenance -->
                    <article id="card-service-maintenance" class="group relative h-[480px] rounded-3xl overflow-hidden border border-white/10 bg-zinc-900">
                        <div class="absolute inset-0">
                            <img src="https://images.pexels.com/photos/4489737/pexels-photo-4489737.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Maintenance" class="w-full h-full object-cover opacity-40 group-hover:opacity-20 transition-opacity duration-500 grayscale group-hover:grayscale-0">
                            <div class="absolute inset-0 bg-gradient-to-b from-transparent via-black/80 to-black"></div>
                        </div>
                        
                        <div class="absolute inset-0 p-8 flex flex-col justify-end">
                            <div class="mb-auto transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                <span class="inline-block px-3 py-1 rounded-full bg-cyan-600 text-white text-xs font-bold mb-4">PASO 2</span>
                            </div>

                            <div class="w-16 h-16 rounded-2xl bg-cyan-600 flex items-center justify-center text-white text-2xl mb-6 shadow-lg shadow-cyan-600/30 group-hover:scale-110 transition-transform duration-300">
                                <i class="fa-solid fa-rotate"></i>
                            </div>
                            
                            <h3 class="text-2xl font-bold text-white mb-3">Mantenimiento Preventivo</h3>
                            <p class="text-gray-400 text-sm mb-6 opacity-80 group-hover:opacity-100 transition-opacity">
                                La seguridad no descansa. Ofrecemos planes de revisión periódica para garantizar que el hardware y el software estén siempre actualizados y funcionales.
                            </p>
                            
                            <ul class="space-y-2 text-sm text-gray-300 border-t border-white/10 pt-4">
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-cyan-500 text-xs"></i> Actualización de Firmware</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-cyan-500 text-xs"></i> Reemplazo de baterías</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-cyan-500 text-xs"></i> Calibración de sensores</li>
                            </ul>
                        </div>
                    </article>

                    <!-- Service Card 3: Support -->
                    <article id="card-service-support" class="group relative h-[480px] rounded-3xl overflow-hidden border border-white/10 bg-zinc-900">
                        <div class="absolute inset-0">
                            <img src="https://images.pexels.com/photos/8867431/pexels-photo-8867431.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Support" class="w-full h-full object-cover opacity-40 group-hover:opacity-20 transition-opacity duration-500 grayscale group-hover:grayscale-0">
                            <div class="absolute inset-0 bg-gradient-to-b from-transparent via-black/80 to-black"></div>
                        </div>
                        
                        <div class="absolute inset-0 p-8 flex flex-col justify-end">
                            <div class="mb-auto transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                <span class="inline-block px-3 py-1 rounded-full bg-indigo-600 text-white text-xs font-bold mb-4">PASO 3</span>
                            </div>

                            <div class="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center text-white text-2xl mb-6 shadow-lg shadow-indigo-600/30 group-hover:scale-110 transition-transform duration-300">
                                <i class="fa-solid fa-headset"></i>
                            </div>
                            
                            <h3 class="text-2xl font-bold text-white mb-3">Soporte Técnico 24/7</h3>
                            <p class="text-gray-400 text-sm mb-6 opacity-80 group-hover:opacity-100 transition-opacity">
                                ¿Problemas de acceso? Nuestro equipo de soporte está disponible en todo momento para resolver incidencias remotamente o enviar una unidad de emergencia.
                            </p>
                            
                            <ul class="space-y-2 text-sm text-gray-300 border-t border-white/10 pt-4">
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-indigo-500 text-xs"></i> Asistencia remota inmediata</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-indigo-500 text-xs"></i> Garantía extendida</li>
                                <li class="flex items-center gap-2"><i class="fa-solid fa-check text-indigo-500 text-xs"></i> Gestión de usuarios perdidos</li>
                            </ul>
                        </div>
                    </article>

                </div>
            </div>
        </section>

        <!-- TECHNICAL SPECS / TRUST INDICATORS -->
        <section id="section-specs" class="py-20 bg-gradient-to-b from-zinc-900 to-black border-t border-white/5">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="glass-card rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-12">
                    <div class="flex-1 space-y-6">
                        <h3 class="text-3xl font-bold text-white">Compatibilidad Universal</h3>
                        <p class="text-gray-400">
                            Nuestros servicios y dispositivos están diseñados para integrarse perfectamente con el ecosistema de tu hogar u oficina. No necesitas cambiar tu puerta, nosotros nos adaptamos.
                        </p>
                        <div class="flex flex-wrap gap-4">
                            <div class="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                                <i class="fa-brands fa-apple text-2xl text-white"></i>
                                <span class="text-sm font-medium text-gray-300">HomeKit</span>
                            </div>
                            <div class="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                                <i class="fa-brands fa-google text-2xl text-white"></i>
                                <span class="text-sm font-medium text-gray-300">Google Home</span>
                            </div>
                            <div class="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                                <i class="fa-brands fa-amazon text-2xl text-white"></i>
                                <span class="text-sm font-medium text-gray-300">Alexa</span>
                            </div>
                            <div class="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                                <i class="fa-solid fa-building text-2xl text-white"></i>
                                <span class="text-sm font-medium text-gray-300">Z-Wave</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-1 w-full">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                                <div class="text-2xl font-bold text-blue-400 mb-1">0.3s</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Velocidad de Apertura</div>
                            </div>
                            <div class="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                                <div class="text-2xl font-bold text-blue-400 mb-1">12m</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Duración Batería</div>
                            </div>
                            <div class="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                                <div class="text-2xl font-bold text-blue-400 mb-1">IP65</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Resistencia Agua</div>
                            </div>
                            <div class="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                                <div class="text-2xl font-bold text-blue-400 mb-1">100</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Huellas Max</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- CTA SECTION -->
        <section id="section-cta" class="py-32 relative overflow-hidden">
            <!-- Glow effect -->
            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none"></div>

            <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
                <h2 class="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                    Protege lo que <br>
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400 animate-pulse">más importa.</span>
                </h2>
                <p class="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
                    Agenda una visita técnica hoy y recibe un diagnóstico de seguridad gratuito para tu hogar o empresa.
                </p>
                
                <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <button class="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] transform hover:-translate-y-1">
                        Solicitar Cotización
                    </button>
                    <button class="w-full sm:w-auto px-8 py-4 bg-transparent border border-white/20 hover:bg-white/5 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2">
                        <i class="fa-brands fa-whatsapp text-green-400 text-xl"></i> Hablar con Asesor
                    </button>
                </div>
                
                <p class="mt-8 text-sm text-gray-500">
                    <i class="fa-solid fa-lock text-xs mr-1"></i> Tus datos están protegidos. Respuesta en menos de 24h.
                </p>
            </div>
        </section>

    </main></body></html>